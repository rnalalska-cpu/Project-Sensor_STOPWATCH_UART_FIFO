`timescale 1ns / 1ps

module display_mux (
    input [1:0] active_src,
    input       disp_mode,
    input       split_mode,

    input [6:0] sw_msec,
    input [5:0] sw_sec,
    input [5:0] sw_min,
    input [4:0] sw_hour,

    input [6:0] split_msec,
    input [5:0] split_sec,
    input [5:0] split_min,
    input [4:0] split_hour,

    input [6:0] wt_msec,
    input [5:0] wt_sec,
    input [5:0] wt_min,
    input [4:0] wt_hour,

    input [8:0] sr04_distance,

    input [7:0] dht11_temp_val,
    input [7:0] dht11_humid_val,
    input [7:0] dht11_fahr_val,
    input [1:0] dht11_disp_sel,

    output reg [6:0] fnd_msec,
    output reg [7:0] fnd_sec,
    output reg [7:0] fnd_min,
    output reg [4:0] fnd_hour,

    output disp_mode_final
);

    wire [6:0] sr04_msec_val;
    wire [6:0] sr04_sec_val;

    assign sr04_msec_val = sr04_distance / 100;
    assign sr04_sec_val  = sr04_distance % 100;

    reg [7:0] dht11_disp_val;

    always @(*) begin
        case (dht11_disp_sel)
            2'b00: dht11_disp_val = dht11_temp_val;

            2'b01: dht11_disp_val = dht11_humid_val;

            2'b10: dht11_disp_val = dht11_fahr_val;

            default: dht11_disp_val = dht11_temp_val;
        endcase
    end

    assign disp_mode_final =
        ((active_src == 2'b00) ||
         (active_src == 2'b11))
        ? 1'b0
        : disp_mode;

    always @(*) begin
        fnd_msec = 7'd0;
        fnd_sec  = 8'd0;
        fnd_min  = 8'd0;
        fnd_hour = 5'd0;

        case (active_src)

            // SR04
            2'b00: begin
                fnd_msec = sr04_sec_val;
                fnd_sec  = sr04_msec_val;
            end

            // Stopwatch
            2'b01: begin
                if (split_mode) begin
                    fnd_msec = split_msec;
                    fnd_sec  = split_sec;
                    fnd_min  = split_min;
                    fnd_hour = split_hour;
                end else begin
                    fnd_msec = sw_msec;
                    fnd_sec  = sw_sec;
                    fnd_min  = sw_min;
                    fnd_hour = sw_hour;
                end
            end

            // Watch
            2'b10: begin
                fnd_msec = wt_msec;
                fnd_sec  = wt_sec;
                fnd_min  = wt_min;
                fnd_hour = wt_hour;
            end

            // DHT11
            2'b11: begin
                fnd_sec = dht11_disp_val;
            end

            default: begin
                fnd_msec = 7'd0;
                fnd_sec  = 8'd0;
                fnd_min  = 8'd0;
                fnd_hour = 5'd0;
            end
        endcase
    end

endmodule
