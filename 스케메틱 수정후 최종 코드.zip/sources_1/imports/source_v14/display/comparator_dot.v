`timescale 1ns / 1ps

module comparator_dot #(
    parameter MSEC_WIDTH = 7
) (
    input [MSEC_WIDTH -1:0] msec,
    output dot_onoff
);
    assign dot_onoff = (msec > 7'b0110010);

endmodule
