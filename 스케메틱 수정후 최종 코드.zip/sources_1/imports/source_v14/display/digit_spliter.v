`timescale 1ns / 1ps

module digit_spliter #(
    parameter BIT_WIDTH = 7
) (
    input  [BIT_WIDTH-1:0] ds_in,
    output [          3:0] digit_1,
    output [          3:0] digit_10

);
    assign digit_1  = ds_in % 10;
    assign digit_10 = (ds_in / 10) % 10;

endmodule
