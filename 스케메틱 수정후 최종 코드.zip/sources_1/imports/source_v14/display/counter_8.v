`timescale 1ns / 1ps

module counter_8 (
    input        clk,
    input        reset,
    output [2:0] digit_sel
);
    reg [2:0] counter_reg;
    assign digit_sel = counter_reg;
    // sequential logic : SL
    always @(posedge clk, posedge reset) begin
        if (reset) begin
            counter_reg <= 0;
        end else begin
            // opertation
            counter_reg <= counter_reg + 1;
        end
    end

endmodule