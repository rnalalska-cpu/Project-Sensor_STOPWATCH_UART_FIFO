`timescale 1ns / 1ps

module fnd_controller #(
    parameter MSEC_WIDTH = 7,
    parameter SEC_WIDTH  = 6,
    parameter MIN_WIDTH  = 6,
    parameter HOUR_WIDTH = 5
) (
    input clk,
    input reset,

    input [MSEC_WIDTH-1:0] msec,
    input [ SEC_WIDTH-1:0] sec,
    input [ MIN_WIDTH-1:0] min,
    input [HOUR_WIDTH-1:0] hour,

    input display_mode,

    input [1:0] active_src,
    input       blink_sec,
    input       blink_min,
    input       blink_hour,

    output [3:0] fnd_com,
    output [7:0] fnd_data
);

    wire [3:0] bcd;
    wire [2:0] w_digit_sel;
    wire       w_1khz;

    wire [3:0] w_msec_digit_1;
    wire [3:0] w_msec_digit_10;

    wire [3:0] w_sec_digit_1;
    wire [3:0] w_sec_digit_10;

    wire [3:0] w_min_digit_1;
    wire [3:0] w_min_digit_10;

    wire [3:0] w_hour_digit_1;
    wire [3:0] w_hour_digit_10;

    wire [3:0] w_msec_sec;
    wire [3:0] w_min_hour;

    wire       w_dot_onoff;

    wire [3:0] w_fnd_com_raw;

    // =========================================================
    // BCD to 7-Segment
    // =========================================================

    bcd U_BCD (
        .bcd_in (bcd),
        .bcd_out(fnd_data)
    );

    // =========================================================
    // 1kHz Clock
    // =========================================================

    clk_div U_CLK_DIV (
        .clk   (clk),
        .reset (reset),
        .o_1khz(w_1khz)
    );

    // =========================================================
    // Digit Splitter
    // =========================================================

    digit_spliter #(
        .BIT_WIDTH(MSEC_WIDTH)
    ) DIGIT_SPLITTER_MSEC (
        .ds_in   (msec),
        .digit_1 (w_msec_digit_1),
        .digit_10(w_msec_digit_10)
    );

    digit_spliter #(
        .BIT_WIDTH(SEC_WIDTH)
    ) DIGIT_SPLITTER_SEC (
        .ds_in   (sec),
        .digit_1 (w_sec_digit_1),
        .digit_10(w_sec_digit_10)
    );

    digit_spliter #(
        .BIT_WIDTH(MIN_WIDTH)
    ) DIGIT_SPLITTER_MIN (
        .ds_in   (min),
        .digit_1 (w_min_digit_1),
        .digit_10(w_min_digit_10)
    );

    digit_spliter #(
        .BIT_WIDTH(HOUR_WIDTH)
    ) DIGIT_SPLITTER_HOUR (
        .ds_in   (hour),
        .digit_1 (w_hour_digit_1),
        .digit_10(w_hour_digit_10)
    );

    // =========================================================
    // Dot Controller
    // =========================================================

    comparator_dot #(
        .MSEC_WIDTH(MSEC_WIDTH)
    ) U_COMPARATOR_DOT (
        .msec     (msec),
        .dot_onoff(w_dot_onoff)
    );

    // =========================================================
    // Digit Scan Counter
    // =========================================================

    counter_8 U_COUNTER_8 (
        .clk      (w_1khz),
        .reset    (reset),
        .digit_sel(w_digit_sel)
    );

    // =========================================================
    // FND Common Decoder
    // =========================================================

    decoder_2x4 U_DECODER_2X4 (
        .digit_sel(w_digit_sel[1:0]),
        .fnd_com  (w_fnd_com_raw)
    );

    // =========================================================
    // MSEC / SEC Data MUX
    // =========================================================

    mux_8x1 U_MUX_8X1_MSEC_SEC (
        .sel    (w_digit_sel),
        .in0    (w_msec_digit_1),
        .in1    (w_msec_digit_10),
        .in2    (w_sec_digit_1),
        .in3    (w_sec_digit_10),
        .in4    (4'b1111),
        .in5    (4'b1111),
        .in6    ({3'b111, w_dot_onoff}),
        .in7    (4'b1111),
        .mux_out(w_msec_sec)
    );

    // =========================================================
    // MIN / HOUR Data MUX
    // =========================================================

    mux_8x1 U_MUX_8X1_MIN_HOUR (
        .sel    (w_digit_sel),
        .in0    (w_min_digit_1),
        .in1    (w_min_digit_10),
        .in2    (w_hour_digit_1),
        .in3    (w_hour_digit_10),
        .in4    (4'b1111),
        .in5    (4'b1111),
        .in6    ({3'b111, w_dot_onoff}),
        .in7    (4'b1111),
        .mux_out(w_min_hour)
    );

    // =========================================================
    // Display Mode MUX
    // =========================================================

    fnd_mux_2x1 U_MUX_2X1 (
        .sel    (display_mode),
        .in0    (w_msec_sec),
        .in1    (w_min_hour),
        .mux_out(bcd)
    );

    // =========================================================
    // Watch Blink Counter
    // =========================================================

    reg [25:0] w_blink_cnt;

    always @(posedge clk, posedge reset) begin
        if (reset) w_blink_cnt <= 26'd0;
        else w_blink_cnt <= w_blink_cnt + 26'd1;
    end

    wire w_blink_off_phase;

    assign w_blink_off_phase = w_blink_cnt[25];

    // =========================================================
    // Watch Blink Select
    // =========================================================

    wire w_need_blank_sec;
    wire w_need_blank_min;
    wire w_need_blank_hour;

    assign w_need_blank_sec =
        (active_src == 2'b10) &&
        blink_sec &&
        (display_mode == 1'b0) &&
        w_blink_off_phase;

    assign w_need_blank_min =
        (active_src == 2'b10) &&
        blink_min &&
        (display_mode == 1'b1) &&
        w_blink_off_phase;

    assign w_need_blank_hour =
        (active_src == 2'b10) &&
        blink_hour &&
        (display_mode == 1'b1) &&
        w_blink_off_phase;

    // =========================================================
    // Blink Mask
    // =========================================================

    wire [3:0] w_blink_mask;

    assign w_blink_mask =
        ({4{w_need_blank_sec}}  & 4'b1100) |
        ({4{w_need_blank_min}}  & 4'b0011) |
        ({4{w_need_blank_hour}} & 4'b1100);

    // =========================================================
    // Final FND Common Output
    // =========================================================

    assign fnd_com = w_fnd_com_raw | w_blink_mask;

endmodule
