`timescale 1ns / 1ps

module clk_div(
    input clk,
    input reset,
    output o_1khz
);
    reg [24:0] counter_reg;
    reg clk_reg;

    assign o_1khz = clk_reg;

    // seqeuntial logic
    always@(posedge clk, posedge reset) begin
        if(reset) begin
            counter_reg <= 0;
            clk_reg <= 1'b0;
        end else begin
            counter_reg <= counter_reg + 1;
            if (counter_reg == 50000 -1 ) begin
                clk_reg <=1'b1;
                counter_reg <= 0;
            end else begin
                clk_reg <=1'b0;

                end
            end
        end
    
endmodule
