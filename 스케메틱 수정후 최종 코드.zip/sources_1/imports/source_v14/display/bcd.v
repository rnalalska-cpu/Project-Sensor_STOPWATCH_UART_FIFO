`timescale 1ns / 1ps

module bcd (
    input      [3:0] bcd_in,
    output reg [7:0] bcd_out
);
    always @(bcd_in) begin
        case (bcd_in)
            4'b0000: bcd_out = 8'hc0;
            4'b0001: bcd_out = 8'hf9;
            4'b0010: bcd_out = 8'ha4;
            4'b0011: bcd_out = 8'hb0;
            4'b0100: bcd_out = 8'h99;
            4'b0101: bcd_out = 8'h92;
            4'b0110: bcd_out = 8'h82;
            4'b0111: bcd_out = 8'hf8;
            4'b1000: bcd_out = 8'h80;
            4'b1001: bcd_out = 8'h90;
            4'b1010: bcd_out = 8'h88;  //a
            4'b1011: bcd_out = 8'h82;  //b
            4'b1100: bcd_out = 8'hc6;  //c
            4'b1101: bcd_out = 8'ha1;  //d
            4'b1110: bcd_out = 8'h7f;  //dot display on
            4'b1111: bcd_out = 8'hff;  //dot display off
        endcase

    end
endmodule
