`timescale 1ns / 1ps

module dht11_controller (
    input clk,
    input reset,
    input start,

    output [15:0] humidity,
    output [15:0] temperature,

    output reg done,
    output reg valid,

    inout dht11_io
);

    // =========================================================
    // FSM State
    // =========================================================

    localparam [2:0]
        IDLE      = 3'd0,
        START     = 3'd1,
        WAIT      = 3'd2,
        SYNC_LOW  = 3'd3,
        SYNC_HIGH = 3'd4,
        DATA_LOW  = 3'd5,
        DATA_HIGH = 3'd6,
        STOP      = 3'd7;

    localparam [14:0] TIMEOUT_US = 15'd100;

    // =========================================================
    // State Register
    // =========================================================

    reg [2:0] c_state;
    reg [2:0] n_state;

    // =========================================================
    // Counter / Data Registers
    // =========================================================

    reg [14:0] tick_count_reg;
    reg [14:0] tick_count_next;

    reg [5:0] bit_count_reg;
    reg [5:0] bit_count_next;

    reg [39:0] data_reg;
    reg [39:0] data_next;

    // =========================================================
    // DHT11 I/O Control
    // =========================================================

    reg io_control;

    reg dht11_io_reg;
    reg dht11_io_next;

    // WAIT state에서 MCU가 line을 release한 뒤
    // HIGH 상태를 확인했는지 저장
    reg wait_released_reg;
    reg wait_released_next;

    // =========================================================
    // Input Synchronizer
    // =========================================================

    reg dht_sync1;
    reg dht_sync2;

    wire dht11_in;
    wire tick_us;

    // =========================================================
    // Checksum
    // =========================================================

    wire [7:0] checksum;
    wire [7:0] calc_checksum;

    // =========================================================
    // DHT11 I/O
    // =========================================================

    assign dht11_io = io_control ? dht11_io_reg : 1'bz;

    assign dht11_in = dht_sync2;

    // =========================================================
    // DHT11 Data Output
    // =========================================================

    assign humidity = data_reg[39:24];

    assign temperature = data_reg[23:8];

    assign checksum = data_reg[7:0];

    assign calc_checksum =
        data_reg[39:32] +
        data_reg[31:24] +
        data_reg[23:16] +
        data_reg[15:8];

    // =========================================================
    // 1us Tick
    // =========================================================

    tick_us U_TICK_US (
        .clk      (clk),
        .reset    (reset),
        .run_stop (1'b1),
        .clear    (1'b0),
        .o_tick_us(tick_us)
    );

    // =========================================================
    // DHT11 Input Synchronizer
    // =========================================================

    always @(posedge clk or posedge reset) begin
        if (reset) begin
            dht_sync1 <= 1'b1;
            dht_sync2 <= 1'b1;
        end else begin
            dht_sync1 <= dht11_io;
            dht_sync2 <= dht_sync1;
        end
    end

    // =========================================================
    // Sequential Logic
    // =========================================================

    always @(posedge clk or posedge reset) begin
        if (reset) begin
            c_state           <= IDLE;

            tick_count_reg    <= 15'd0;
            bit_count_reg     <= 6'd0;
            data_reg          <= 40'd0;

            dht11_io_reg      <= 1'b1;

            wait_released_reg <= 1'b0;
        end else begin
            c_state           <= n_state;

            tick_count_reg    <= tick_count_next;
            bit_count_reg     <= bit_count_next;
            data_reg          <= data_next;

            dht11_io_reg      <= dht11_io_next;

            wait_released_reg <= wait_released_next;
        end
    end

    // =========================================================
    // FSM Combinational Logic
    // =========================================================

    always @(*) begin

        n_state            = c_state;

        tick_count_next    = tick_count_reg;
        bit_count_next     = bit_count_reg;
        data_next          = data_reg;

        dht11_io_next      = dht11_io_reg;

        wait_released_next = wait_released_reg;

        io_control         = 1'b0;

        done               = 1'b0;
        valid              = 1'b0;

        case (c_state)

            // =================================================
            // IDLE
            // =================================================

            IDLE: begin
                tick_count_next    = 15'd0;
                bit_count_next     = 6'd0;
                wait_released_next = 1'b0;

                if (start) begin
                    tick_count_next = 15'd0;
                    n_state         = START;
                end
            end

            // =================================================
            // START
            // MCU drives LOW for about 19ms
            // =================================================

            START: begin

                io_control    = 1'b1;
                dht11_io_next = 1'b0;

                if (tick_us) begin

                    if (tick_count_reg == 15'd18999) begin

                        tick_count_next    = 15'd0;
                        wait_released_next = 1'b0;

                        n_state = WAIT;

                    end else begin

                        tick_count_next = tick_count_reg + 1'b1;

                    end
                end
            end

            // =================================================
            // WAIT
            // MCU releases line and waits for sensor response
            // =================================================

            WAIT: begin

                // 먼저 line이 HIGH로 release 되었는지 확인
                if (!wait_released_reg) begin

                    if (dht11_in) begin

                        wait_released_next = 1'b1;
                        tick_count_next    = 15'd0;

                    end else if (tick_us) begin

                        if (tick_count_reg >= TIMEOUT_US) begin

                            tick_count_next = 15'd0;
                            n_state         = IDLE;

                        end else begin

                            tick_count_next = tick_count_reg + 1'b1;

                        end
                    end
                end  // HIGH 확인 후 DHT11 response LOW 대기
                else begin

                    if (!dht11_in) begin

                        tick_count_next = 15'd0;

                        n_state = SYNC_LOW;

                    end else if (tick_us) begin

                        if (tick_count_reg >= TIMEOUT_US) begin

                            tick_count_next = 15'd0;
                            n_state         = IDLE;

                        end else begin

                            tick_count_next = tick_count_reg + 1'b1;

                        end
                    end
                end
            end

            // =================================================
            // SYNC_LOW
            // DHT11 response LOW pulse
            // =================================================

            SYNC_LOW: begin

                if (dht11_in) begin

                    tick_count_next = 15'd0;

                    n_state = SYNC_HIGH;

                end else if (tick_us) begin

                    if (tick_count_reg >= TIMEOUT_US) begin

                        tick_count_next = 15'd0;

                        n_state = IDLE;

                    end else begin

                        tick_count_next = tick_count_reg + 1'b1;

                    end
                end
            end

            // =================================================
            // SYNC_HIGH
            // DHT11 response HIGH pulse
            // =================================================

            SYNC_HIGH: begin

                if (!dht11_in) begin

                    tick_count_next = 15'd0;
                    bit_count_next = 6'd0;

                    n_state = DATA_LOW;

                end else if (tick_us) begin

                    if (tick_count_reg >= TIMEOUT_US) begin

                        tick_count_next = 15'd0;

                        n_state = IDLE;

                    end else begin

                        tick_count_next = tick_count_reg + 1'b1;

                    end
                end
            end

            // =================================================
            // DATA_LOW
            // Each data bit begins with LOW pulse
            // =================================================

            DATA_LOW: begin

                if (dht11_in) begin

                    tick_count_next = 15'd0;

                    n_state = DATA_HIGH;

                end else if (tick_us) begin

                    if (tick_count_reg >= TIMEOUT_US) begin

                        tick_count_next = 15'd0;

                        n_state = IDLE;

                    end else begin

                        tick_count_next = tick_count_reg + 1'b1;

                    end
                end
            end

            // =================================================
            // DATA_HIGH
            // HIGH pulse width determines 0 or 1
            // =================================================

            DATA_HIGH: begin

                if (dht11_in) begin

                    if (tick_us) begin

                        if (tick_count_reg >= TIMEOUT_US) begin

                            tick_count_next = 15'd0;

                            n_state = IDLE;

                        end else begin

                            tick_count_next = tick_count_reg + 1'b1;

                        end
                    end

                end else begin

                    // HIGH pulse >= 50us -> Logic 1
                    if (tick_count_reg >= 15'd50) begin

                        data_next = {data_reg[38:0], 1'b1};

                    end  // HIGH pulse < 50us -> Logic 0
                    else begin

                        data_next = {data_reg[38:0], 1'b0};

                    end

                    tick_count_next = 15'd0;

                    // 40bit 수신 완료
                    if (bit_count_reg == 6'd39) begin

                        n_state = STOP;

                    end  // 다음 data bit
                    else begin

                        bit_count_next = bit_count_reg + 1'b1;

                        n_state = DATA_LOW;

                    end
                end
            end

            // =================================================
            // STOP
            // Checksum validation
            // =================================================

            STOP: begin

                done = 1'b1;

                if (checksum == calc_checksum) valid = 1'b1;
                else valid = 1'b0;

                tick_count_next = 15'd0;

                n_state = IDLE;
            end

            // =================================================
            // Default
            // =================================================

            default: begin

                n_state            = IDLE;

                tick_count_next    = 15'd0;
                bit_count_next     = 6'd0;
                data_next          = 40'd0;

                wait_released_next = 1'b0;

            end

        endcase
    end

endmodule
