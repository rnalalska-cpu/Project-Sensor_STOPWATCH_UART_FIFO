`timescale 1ns / 1ps

module dht11_control_unit (
    input  clk,
    input  reset,
    input  i_start,
    output o_start
);

    parameter IDLE = 1'b0, START = 1'b1;

    reg c_state, n_state;

    reg start_reg, start_next;

    assign o_start = start_reg;

    always @(posedge clk, posedge reset) begin
        if (reset) begin
            c_state   <= IDLE;
            start_reg <= 1'b0;
        end else begin
            c_state   <= n_state;
            start_reg <= start_next;
        end
    end

    always @(*) begin
        n_state    = c_state;
        start_next = start_reg;

        case (c_state)
            IDLE: begin
                start_next = 1'b0;

                if (i_start) n_state = START;
            end

            START: begin
                start_next = 1'b1;
                n_state    = IDLE;
            end

            default: begin
                n_state    = IDLE;
                start_next = 1'b0;
            end
        endcase
    end

endmodule
