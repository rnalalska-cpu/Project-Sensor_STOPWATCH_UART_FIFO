`timescale 1ns / 1ps

module dht11 (
    input clk,
    input reset,
    input start,

    output [15:0] humidity,
    output [15:0] temperature,
    output [ 7:0] fahrenheit,

    output done,
    output valid,

    inout dht11_io
);

    wire [ 7:0] temperature_val;
    wire [10:0] fahrenheit_calc;

    dht11_controller U_DHT11_CONTROLLER (
        .clk        (clk),
        .reset      (reset),
        .start      (start),
        .humidity   (humidity),
        .temperature(temperature),
        .done       (done),
        .valid      (valid),
        .dht11_io   (dht11_io)
    );

    assign temperature_val = temperature[15:8];

    assign fahrenheit_calc = (temperature_val * 9) / 5 + 32;

    assign fahrenheit = fahrenheit_calc[7:0];

endmodule
