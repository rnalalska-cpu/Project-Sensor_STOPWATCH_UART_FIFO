`timescale 1ns / 1ps

module watch_time_counter #(
    parameter BIT_WIDTH = 7,
    TIMES = 100,
    TIME = 0
) (
    input                      clk,
    input                      reset,
    input                      i_tick,
    input      [          1:0] set_time,
    output     [BIT_WIDTH-1:0] time_count,
    output reg                 o_tick
);

    reg [$clog2(TIMES)-1:0] count_reg;

    assign time_count = count_reg;

    always @(posedge clk, posedge reset) begin
        if (reset) begin
            count_reg <= TIME;
            o_tick <= 1'b0;
        end else begin
            if (set_time[1]) begin
                if (count_reg == TIMES - 1) count_reg <= 0;
                else count_reg <= count_reg + 1;
            end else if (set_time[0]) begin
                if (count_reg == 0) count_reg <= TIMES - 1;
                else count_reg <= count_reg - 1;
            end else if (i_tick) begin
                count_reg <= count_reg + 1;

                if (count_reg == TIMES - 1) begin
                    count_reg <= 0;
                    o_tick <= 1'b1;
                end
            end else begin
                o_tick <= 1'b0;
            end
        end
    end

endmodule
