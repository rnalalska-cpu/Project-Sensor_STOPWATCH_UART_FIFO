module watch_control_unit (
    input clk,
    input reset,

    input    [3:0] i_ascii, 

    input i_btn_L,
    input i_btn_R,
    input i_btn_U,
    input i_btn_D,

    input i_set_sw,

    output [1:0] o_change_sec,
    output [1:0] o_change_min,
    output [1:0] o_change_hour,

    output o_blink_sec,
    output o_blink_min,
    output o_blink_hour
);

    wire w_btn_U = i_btn_U | i_ascii[3];
    wire w_btn_D = i_btn_D | i_ascii[2];
    wire w_btn_L = i_btn_L | i_ascii[1];
    wire w_btn_R = i_btn_R | i_ascii[0];

    parameter WATCH = 0, SET_SEC = 1, SET_MIN = 2, SET_HOUR = 3;
    reg [1:0] c_state, n_state;

    always @(posedge clk, posedge reset) begin
        if (reset) c_state <= WATCH;
        else c_state <= n_state;
    end

    assign o_change_sec  = (c_state == SET_SEC) ? {w_btn_U, w_btn_D} : 2'b00;
    assign o_change_min  = (c_state == SET_MIN) ? {w_btn_U, w_btn_D} : 2'b00;
    assign o_change_hour = (c_state == SET_HOUR) ? {w_btn_U, w_btn_D} : 2'b00;

    assign o_blink_sec   = (c_state == SET_SEC);
    assign o_blink_min   = (c_state == SET_MIN);
    assign o_blink_hour  = (c_state == SET_HOUR);

    always @(*) begin
        n_state = c_state;

        case (c_state)
            WATCH:
            if (i_set_sw == 1) n_state = SET_SEC;
            else n_state = WATCH;

            SET_SEC:
            if (i_set_sw == 1) begin
                if (w_btn_L) n_state = SET_MIN;  
                else if (w_btn_R) n_state = SET_HOUR;  
            end else n_state = WATCH;

            SET_MIN:
            if (i_set_sw == 1) begin
                if (w_btn_L) n_state = SET_HOUR;
                else if (w_btn_R) n_state = SET_SEC;
            end else n_state = WATCH;

            SET_HOUR:
            if (i_set_sw == 1) begin
                if (w_btn_L) n_state = SET_SEC;
                else if (w_btn_R) n_state = SET_MIN;
            end else n_state = WATCH;
        endcase
    end

endmodule