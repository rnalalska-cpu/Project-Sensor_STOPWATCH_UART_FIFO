`timescale 1ns / 1ps

module register_file #(
    parameter WIDTH = 2
) (
    input              clk,
    input  [WIDTH-1:0] waddr,
    input  [WIDTH-1:0] raddr,
    input  [      7:0] wdata,
    input              we,
    output [      7:0] rdata

);

    parameter DEPTH = 2 ** WIDTH;
    reg [7:0] register_file[0:DEPTH-1];

    always @(posedge clk) begin
        if (we) begin
            register_file[waddr] <= wdata;
        end
    end

    assign rdata = register_file[raddr];

endmodule