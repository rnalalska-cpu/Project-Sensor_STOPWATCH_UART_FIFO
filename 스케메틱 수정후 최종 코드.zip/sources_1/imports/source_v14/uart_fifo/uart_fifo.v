`timescale 1ns / 1ps

module uart_fifo #(
    parameter FIFO_WIDTH = 4
) (
    input clk,
    input reset,

    input  rx,
    output tx,

    output [7:0] rx_rdata,
    output       rx_empty,
    input        rx_pop,

    input  [7:0] tx_wdata,
    input        tx_push,
    output       tx_full
);

    wire [7:0] w_uart_rx_data;
    wire       w_uart_rx_done;

    wire [7:0] w_tx_fifo_rdata;
    wire       w_tx_fifo_empty;
    wire       w_uart_tx_busy;
    wire       w_uart_tx_start;

    uart_controller U_UART_CTRL (
        .clk     (clk),
        .reset   (reset),
        .tx_start(w_uart_tx_start),
        .tx_data (w_tx_fifo_rdata),
        .rx      (rx),
        .rx_data (w_uart_rx_data),
        .rx_done (w_uart_rx_done),
        .tx_busy (w_uart_tx_busy),
        .tx_done (),
        .tx      (tx)
    );

    fifo #(
        .WIDTH(FIFO_WIDTH)
    ) U_FIFO_RX (
        .clk  (clk),
        .reset(reset),
        .push (w_uart_rx_done),
        .pop  (rx_pop),
        .wdata(w_uart_rx_data),
        .rdata(rx_rdata),
        .full (),
        .empty(rx_empty)
    );

    fifo #(
        .WIDTH(FIFO_WIDTH)
    ) U_FIFO_TX (
        .clk  (clk),
        .reset(reset),
        .push (tx_push),
        .pop  (w_uart_tx_start),
        .wdata(tx_wdata),
        .rdata(w_tx_fifo_rdata),
        .full (tx_full),
        .empty(w_tx_fifo_empty)
    );

    assign w_uart_tx_start = ~w_tx_fifo_empty & ~w_uart_tx_busy;

endmodule
