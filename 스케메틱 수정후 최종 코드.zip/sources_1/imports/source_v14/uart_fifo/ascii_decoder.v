`timescale 1ns / 1ps

module ascii_decoder (
    input      [ 7:0] rdata,
    input             empty,
    output            pop,
    output reg [14:0] o_ascii
);

    assign pop = ~empty;

    always @(*) begin
        o_ascii = 15'h000;
        if (~empty) begin
            case (rdata)
                8'h72: begin  //r (stopwatch run)
                    o_ascii[0] = 1;
                end
                8'h73: begin  //s (stopwatch stop)
                    o_ascii[1] = 1;
                end
                8'h63: begin  //c (stopwatch clear)
                    o_ascii[2] = 1;
                end
                8'h6d: begin  //m (stopwatch  mode)
                    o_ascii[3] = 1;
                end
                8'h53: begin  //S ()
                    o_ascii[4] = 1;
                end
                8'h4d: begin  //M
                    o_ascii[5] = 1;
                end
                8'h48: begin  //H (DHT11 습도 표시)
                    o_ascii[6] = 1;
                end
                8'h64: begin  //d (SR04 시작)
                    o_ascii[7] = 1;
                end
                8'h46: begin  //F (DHT11 화씨 표시)
                    o_ascii[8] = 1;
                end
                8'h54: begin  //T (DHT11 측정 시작)
                    o_ascii[9] = 1;
                end
                8'h43: begin  //C (DHT11 섭씨 표시)
                    o_ascii[10] = 1;
                end
                8'h4c: begin
                    o_ascii[11] = 1;  // L (watch left select)
                end
                8'h52: begin
                    o_ascii[12] = 1;  // R (watch right select)
                end
                8'h55: begin
                    o_ascii[13] = 1;  // U (watch up time count)
                end
                8'h44: begin
                    o_ascii[14] = 1;  // D (watch down time count)
                end
            endcase
        end
    end
endmodule
