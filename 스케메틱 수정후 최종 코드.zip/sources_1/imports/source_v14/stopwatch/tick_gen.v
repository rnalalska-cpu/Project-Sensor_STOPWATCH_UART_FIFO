`timescale 1ns / 1ps

module tick_gen (
    input      clk,
    input      reset,
    output reg o_tick
);
    reg [$clog2(1_000_000) -1:0] tick_count;

    always @(posedge clk, posedge reset) begin
        if (reset) begin
            tick_count <= 0;
            o_tick <= 1'b0;
        end else begin
            tick_count = tick_count + 1;
            if (tick_count == 1_000_000 - 1) begin
                tick_count <= 0;
                o_tick <= 1'b1;
            end else begin
                o_tick <= 1'b0;
            end
        end
    end

endmodule
